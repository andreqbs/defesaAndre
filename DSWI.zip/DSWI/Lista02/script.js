function ex01() {
  var num1	=	window.prompt("Digite o seu nome");
  window.alert(num1.length);
  document.writeln(num1.length);
}

function ex02() {
  var gosto	=	window.prompt("Esta gostando de JS?");
  if(gosto.toUpperCase() == 'SIM') {
    window.alert(gosto + ":)");
    document.writeln(gosto);
  }
  else if (gosto.toUpperCase() == "NÃO" || gosto.toUpperCase() == "NAO") {
    window.alert(gosto + ":(");
    document.writeln(gosto);
  }
  else {
    questoes();
  }
}

function ex03() {
  var vetorNum	=	[];
  var numeros;
  for (var i = 0; i < 5; i++) {
    numeros = window.prompt("Digite o " + (i+1) + "numero");
    vetorNum[i] = parseInt(numeros);
  }
  var soma = 0;
  for (var i = 0; i < 5; i++) {
    soma += vetorNum[i];
  }
  window.alert(soma);
  document.writeln(soma);
}

function ex04() {
  var vetorNum	=	[];
  var numeros;
  var indice = 0;
  do {
    numeros	=	window.prompt("Digite numero maior que zero");
    vetorNum[indice] = parseInt(numeros);
    indice++;
  } while (numeros > 0);
  var soma = 0;
  for (var i = 0; i < vetorNum.length; i++) {
   soma+= vetorNum[i];
  }
  window.alert(soma/indice);
  document.writeln(soma/indice);
}

function ex05() {
  var v1	=	[1,2,3,4,5];
  var v2	=	[6,7,8,9,10];
  var soma = 0;
  for (var i = 0; i < v1.length; i++) {
    soma += v1[i] + v2[i];
  }
  window.alert(soma);
  document.writeln(soma);
}

function ex06() {
  var nome	=	window.prompt("Informe seu nome completo");
  var vetorNome = nome.split(" ");
  document.writeln("<table style='width:100%'>");
  document.writeln("<tr> <th colspan='2'>" + nome.toUpperCase() + "</th></tr><tr>");
  for (var i = 0; i < vetorNome.length; i++) {
      document.writeln("<td>" + vetorNome[i] + "</td>");
  }
  document.writeln("</tr><tr>");
  for (var i = 0; i < vetorNome.length; i++) {
      document.writeln("<td>" + vetorNome[i].length + "</td>");
  }
  document.writeln("</tr></table>");
}

function ex07() {
  var valor	=	window.prompt("Digite um valor que seja diferente de zero");
  var qntd = 0;
  var soma = 0;
  var valorConvt;
  do {
    valor	=	window.prompt("Digite um valor que seja diferente de zero");
    valorConvt = parseInt(valor);
    qntd++;
    soma += valorConvt;

  } while (valorConvt != 0);
  window.alert("Quantidade " + qntd + " / Soma " + soma + " / Media " + soma/qntd);
  document.writeln("Quantidade " + qntd + " / Soma " + soma + " / Media " + soma/qntd);
}

function questoes() {
  var questao	=	window.prompt("Digite a questao");
  var escolha = parseInt(questao);

  if(escolha == 1) {
    ex01();
  }
  else if(escolha == 2) {
    ex02();
  }
  else if(escolha == 3) {
    ex03();
  }
  else if(escolha == 4) {
    ex04();
  }
  else if(escolha == 5) {
    ex05();
  }
  else if(escolha == 6) {
    ex06();
  }
  else if(escolha == 7) {
    ex07();
  }
  else {
    questoes();
  }
}
