function Pessoa( pNome,  uNome,  dataNasc,  altura,  peso,  sexo) {
  this.primeiroNome = pNome;
  this.ultimoNome = uNome;
  this.dataNascimento = dataNasc;
  this.altura = altura;
  this.peso = peso;
  this.sexo = sexo;

  this.getNomeCompleto = function()
  {
    return this.primeiroNome + " " + this.ultimoNome;
  }

  this.getIdadeAtual = function() {
    var d = new Date();
    var n = d.getFullYear();
    var data = this.dataNascimento.split("/");
    return (parseInt(n) - parseInt(data[0]));
  }

  this.getDataNascimento = function() {
    return this.dataNascimento;
  }

  this.getDiaNascimento = function() {
    var dia = this.dataNascimento.split("/");
    return dia[2];
  }

  this.getMesNascimento = function() {
    var mes = this.dataNascimento.split("/");
    return mes[1];
  }

  this.getAnoNascimento = function() {
    var ano = this.dataNascimento.split("/");
    return ano[0];
  }

  this.getSexo = function() {
    return this.sexo;
  }

  this.getImc = function() {
    return parseInt(this.peso) / ((parseInt(this.altura) / 100) * ((parseInt(this.altura) / 100)));
  }
}

function cadastroPessoas() {
  var vetor = [];
  do {
    var pNome = window.prompt("Seu nome");
    var uNome = window.prompt("Seu sobrenome");
    var dataNasc = window.prompt("Sua data nascimento");
    var altura = window.prompt("Sua altura");
    var peso = window.prompt("seu peso");
    var sexo = window.prompt("seu sexo");
    var pessoa = new Pessoa(pNome, uNome, dataNasc, altura, peso, sexo);
    vetor.push(pessoa);
    var opcao = window.prompt("Adicionar uma nova pessoa");
  } while(opcao != "nao");

  var byName = vetor.slice(0);
  byName.sort(function(a,b) {
    var x = a.primeiroNome.toLowerCase();
    var y = b.primeiroNome.toLowerCase();
    return x < y ? -1 : x > y ? 1 : 0;
  });
  document.writeln("<link rel='stylesheet' type='text/css' href='style.css'>");
  document.writeln("<table>");
  document.writeln("<tr><th>Nome</th><th>Idade</th><th>Sexo</th><th>Data Nascimento</th><th>IMC</th><tr>");
  for (var i = 0; i < byName.length; i++) {
    exibir(byName[i]);
  }
  document.writeln("</table>");
}

function exibir(pessoa) {
  document.writeln("<tr><td>"+pessoa.getNomeCompleto()+"</td><td>"+pessoa.getIdadeAtual()+"</td><td>"+pessoa.getSexo()+"</td><td>"+pessoa.getDataNascimento()+"</td><td>"+pessoa.getImc()+"</td><tr>");
}

/*
------------------------------------------------------------------------------------------------
*/

function Aluno( nome,  nota1,  nota2, faltas) {
  this.nome = nome;
  this.notaBim1 = nota1;
  this.notaBim2 = nota2;
  this.numFaltas = faltas;

  this.getNome = function()
  {
    return this.nome;
  }

  this.getNota1 = function() {
    return this.notaBim1;
  }


  this.getNota2 = function() {
      return this.notaBim2;
    }

  this.calcMedia = function() {
    return ((parseInt(this.notaBim1) + parseInt(this.notaBim2)) / 2);
  }

  this.calcFreq = function(totalAulas) {
    return (1 - this.numFaltas / totalAulas) * 100;
  }
}

function cadastroAlunos() {
  var vetor = [];
  do {
    var nomeAluno = window.prompt("Nome do aluno");
    var nota1bm = window.prompt("Nota do 1 BIM");
    var nota2bm = window.prompt("Nota do 2 BIM");
    var faltas = window.prompt("Total de faltas");
    var aluno = new Aluno(nomeAluno, nota1bm, nota2bm, faltas);
    vetor.push(aluno);
    var opcao = window.prompt("Adicionar um novo aluno?");
  } while(opcao != "nao");

  var tAulas = window.prompt("Total de aulas ministradas");

  var byName = vetor.slice(0);
  byName.sort(function(a,b) {
    var x = a.nome.toLowerCase();
    var y = b.nome.toLowerCase();
    return x < y ? -1 : x > y ? 1 : 0;
  });
  document.writeln("<link rel='stylesheet' type='text/css' href='style.css'>");
  document.writeln("<table>");
  document.writeln("<tr><th>Nome</th><th>1 Semestre</th><th>2 Semestre</th><th>Media Final</th><th>Frequencia</th><tr>");
  for (var i = 0; i < byName.length; i++) {
    exibirAluno(byName[i], tAulas);
  }
  document.writeln("</table>");
}

function exibirAluno(aluno, tAulas) {
  if(aluno.calcMedia() >= 7.0 &&  aluno.calcFreq(tAulas) >= 75) {
    document.writeln("<tr bgcolor='#00FF00'><td>"+aluno.getNome()+"</td><td>"+aluno.getNota1()+"</td><td>"+aluno.getNota2()+"</td><td>"+aluno.calcMedia()+"</td><td>"+aluno.calcFreq(tAulas)+" %</td><tr>");
  }
  else {
    document.writeln("<tr bgcolor='#FF0000'><td>"+aluno.getNome()+"</td><td>"+aluno.getNota1()+"</td><td>"+aluno.getNota2()+"</td><td>"+aluno.calcMedia()+"</td><td>"+aluno.calcFreq(tAulas)+" %</td><tr>");
  }
}
