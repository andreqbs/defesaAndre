function ex01() {
  var num1	=	window.prompt("Digite o primeiro numero");
  var num2	=	window.prompt("Digite o segundo numero");
  var soma = parseInt(num1)+parseInt(num2);
  window.alert(soma);
  document.writeln(soma);
}

function ex02() {
  var metros	=	window.prompt("Digite o valor em metros");
  var mm = 10*parseInt(metros);
  window.alert(mm + " mm");
  document.writeln(mm + " mm");
}

function ex03() {
  var dias	=	window.prompt("Digite a quantidade de dias");
  var horas	=	window.prompt("Digite a quantidade de horas");
  var minutos	=	window.prompt("Digite a quantidade de minutos");
  var segundos	=	window.prompt("Digite a quantidade de segundos");
  var total = parseInt(dias*24*3600) + (horas*3600) + (minutos*60)+ parseInt(segundos);
  window.alert(total + " segundos");
  document.writeln(total + " segundos");
}

function ex04() {
  var salario	=	window.prompt("Digite o salario atual");
  var aumento	=	window.prompt("Digite o aumento");
  var salarioFinal	=	salario * (1 + parseInt(aumento)/100);
  window.alert("R$" + salarioFinal);
  document.writeln("R$" + salarioFinal);
}

function ex05() {
  var preco	=	window.prompt("Digite o preco da mercadoria");
  var desconto	=	window.prompt("Digite o desconto");
  var precoFinal	=	preco * (1 - parseInt(desconto)/100);
  window.alert("R$" + precoFinal);
  document.writeln("R$" + precoFinal);
}

function ex06() {
  var num1	=	window.prompt("Digite o primeiro numero");
  var num2	=	window.prompt("Digite o segundo numero");
  if(num1 > num2) {
    window.alert(num1);
    document.writeln(num1);
  }
  else if (num2 > num1) {
    window.alert(num2);
    document.writeln(num2);
  }
  else {
    window.alert("iguais");
    document.writeln("iguais");
  }
}

function ex07() {
  var valor	=	window.prompt("Digite um valor que seja diferente de zero");
  var qntd = 0;
  var soma = 0;
  var valorConvt;
  do {
    valor	=	window.prompt("Digite um valor que seja diferente de zero");
    valorConvt = parseInt(valor);
    qntd++;
    soma += valorConvt;

  } while (valorConvt != 0);
  window.alert("Quantidade " + qntd + " / Soma " + soma + " / Media " + soma/qntd);
  document.writeln("Quantidade " + qntd + " / Soma " + soma + " / Media " + soma/qntd);
}

function questoes() {
  var questao	=	window.prompt("Digite a questao");
  var escolha = parseInt(questao);

  if(escolha == 1) {
    ex01();
  }
  else if(escolha == 2) {
    ex02();
  }
  else if(escolha == 3) {
    ex03();
  }
  else if(escolha == 4) {
    ex04();
  }
  else if(escolha == 5) {
    ex05();
  }
  else if(escolha == 6) {
    ex06();
  }
  else if(escolha == 7) {
    ex07();
  }
  else {
    questoes();
  }
}
