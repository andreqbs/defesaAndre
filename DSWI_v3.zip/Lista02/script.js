function ex01() {
  var num1	=	window.prompt("Digite o seu nome");
  window.alert(num1.length);
  document.writeln(num1.length);
}

function ex02() {
  var gosto	=	window.prompt("Esta gostando de JS?");
  if(gosto.toUpperCase() == 'SIM') {
    window.alert(gosto + ":)");
    document.writeln(gosto);
  }
  else if (gosto.toUpperCase() == "NÃO" || gosto.toUpperCase() == "NAO") {
    window.alert(gosto + ":(");
    document.writeln(gosto);
  }
  else {
    questoes();
  }
}

function ex03() {
  var vetorNum	=	[];
  var numeros;
  for (var i = 0; i < 5; i++) {
    numeros = window.prompt("Digite o " + (i+1) + "numero");
    vetorNum[i] = parseInt(numeros);
  }
  var soma = 0;
  for (var i = 0; i < 5; i++) {
    soma += vetorNum[i];
  }
  window.alert(soma);
  document.writeln(soma);
}

function ex04() {
  var vetorNum	=	[];
  var numeros;
  var indice = 0;
  do {
    numeros	=	window.prompt("Digite numero maior que zero");
    vetorNum[indice] = parseInt(numeros);
    indice++;
  } while (numeros > 0);
  var soma = 0;
  for (var i = 0; i < vetorNum.length; i++) {
    soma+= vetorNum[i];
  }
  window.alert(soma/indice);
  document.writeln(soma/indice);
}

function ex05() {
  var v1	=	[1,2,3,4,5];
  var v2	=	[6,7,8,9,10];
  var soma = 0;
  for (var i = 0; i < v1.length; i++) {
    soma += v1[i] + v2[i];
  }
  window.alert(soma);
  document.writeln(soma);
}

function ex06() {
  var nome	=	window.prompt("Informe seu nome completo");
  var vetorNome = nome.split(" ");
  document.writeln("<table style='width:100%'>");
  document.writeln("<tr> <th colspan='2'>" + nome.toUpperCase() + "</th></tr><tr>");
  for (var i = 0; i < vetorNome.length; i++) {
    document.writeln("<td>" + vetorNome[i] + "</td>");
  }
  document.writeln("</tr><tr>");
  for (var i = 0; i < vetorNome.length; i++) {
    document.writeln("<td>" + vetorNome[i].length + "</td>");
  }
  document.writeln("</tr></table>");
}

function ex07() {
  var nome	=	window.prompt("Informe seu nome completo");
  var matricula	=	window.prompt("Digite sua matricula");
  var valorHora	=	window.prompt("Digite seu valor/hora");
  var totalHoras	=	window.prompt("Digite a quantidadede horas trabalhadas");
  var filhos	=	window.prompt("Digite a quantidade de filhos menores que 18 anos");
  var salarioParcial = parseInt(valorHora) * parseInt(totalHoras);
  var salarioFinal = parseInt(filhos)*(0.08*salarioParcial) + salarioParcial;

  document.writeln("<table style='width:100%'>");
  document.writeln("<tr> <th colspan='2'>" + nome.toUpperCase() + "</th></tr>");
  document.writeln("<tr><td>Matricula</td>");
  document.writeln("<td>" + matricula + "</td></tr>");
  document.writeln("<tr><td>Valor da hora/trabalho</td>");
  document.writeln("<td>" + valorHora + "</td></tr>");
  document.writeln("<tr><td>Total de horas trabalhadas</td>");
  document.writeln("<td>" + totalHoras + "</td></tr>");
  document.writeln("<tr><td>Quantidade de filhos (<18)</td>");
  document.writeln("<td>" + filhos + "</td></tr>");
  document.writeln("<tr><td>Salário Final</td>");
  document.writeln("<td>" + salarioFinal + "</td></tr>");
  document.writeln("</table>");
}

function ex08() {
  var vImagens = [];
  var urlAux;
  var encontrado = 0;
  var gosto	=	window.prompt("Deseja adicionar uma imagem?");
  while (gosto.toUpperCase() == 'SIM') {
    var url	=	window.prompt("Informe a URL da imagem");
    var altura	=	window.prompt("Informe a altura da imagem");
    var largura	=	window.prompt("Informe a largura da imagem");

    for (var i = 0; i < vImagens.length; i++) {
      urlAux = vImagens[i].split(",");
      if(url == urlAux[0]) {
        gosto	=	window.prompt("Deseja atualizar a imagem?");
        if(gosto.toUpperCase() == 'SIM') {
          encontrado = 1;
          vImagens[i] = url+","+altura+","+largura;
          break;
        }
      }
    }
    if (encontrado != 1) {
      vImagens.push(url+","+altura+","+largura);
    }
    gosto	=	window.prompt("Deseja adicionar uma imagem?");
    encontrado = 0;
  }
  for (var i = 0; i < vImagens.length; i++) {
    urlAux = vImagens[i].split(",");
    document.writeln("<img src='"+urlAux[0]+"' height='"+parseInt(urlAux[1])+"' width='"+parseInt(urlAux[2])+"'>");
  }
}

function questoes() {
  var questao	=	window.prompt("Digite a questao");
  var escolha = parseInt(questao);

  if(escolha == 1) {
    ex01();
  }
  else if(escolha == 2) {
    ex02();
  }
  else if(escolha == 3) {
    ex03();
  }
  else if(escolha == 4) {
    ex04();
  }
  else if(escolha == 5) {
    ex05();
  }
  else if(escolha == 6) {
    ex06();
  }
  else if(escolha == 7) {
    ex07();
  }
  else if(escolha == 8) {
    ex08();
  }
  else {
    questoes();
  }
}
